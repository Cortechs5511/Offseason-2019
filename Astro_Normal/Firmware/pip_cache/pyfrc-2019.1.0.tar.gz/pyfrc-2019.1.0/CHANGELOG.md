v2015.1.0
---------
* Use pure python WPILib for 2015, remove old wpilib stubs
* Various roborio control system updates
* Migrate samples to new WPILib API
* Migrate non-pyfrc documentation to WPILib

v2014.7.5
---------
* Fix IterativeRobot support in simulator

v2014.7.4
---------
* Fix gyro simulation to start at zero

v2014.7.3
---------
* Include a field in the simulation display
* Add test scripts for pyfrc itself
* Add sphinx documentation

v2014.6.0
---------
* Move generic tests to pyfrc.tests
* IsEnabled() is now IsEnabled(tm), to match other signatures
* Addition of PracticeMatchTestController

v2014.5.5
---------
* Add support for displaying 'label' attribute in sim UI 

Pre-2014.5.5
------------

TODO: Create changelog for older changes too
