===================
License and Credits
===================

``attrs`` is licensed under the `MIT <https://choosealicense.com/licenses/mit/>`_ license.
The full license text can be also found in the `source code repository <https://github.com/python-attrs/attrs/blob/master/LICENSE>`_.

.. include:: ../AUTHORS.rst
