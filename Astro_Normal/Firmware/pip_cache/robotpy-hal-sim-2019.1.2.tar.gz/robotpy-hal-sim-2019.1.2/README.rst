robotpy-hal-sim
===============

This robotpy HAL implementation writes all data to a single dictionary,
and is useful for simulation and testing of robot code on a PC.

Installation
============

Typically, you don't install this directly, but it is installed by pip when
installing pyfrc.
