robotpy-navx
============

This is a python implementation of the kauailabs NavX library.

.. note:: The RobotPy project is not associated with or endorsed by kauailabs

Documentation
=============

* `Installation <http://robotpy.readthedocs.io/en/stable/install/navx.html>`_
* `Python API Documentation <http://robotpy.readthedocs.io/projects/navx/en/stable/api.html>`_

License
=======

The original NavX software is available under the MIT license, as is this.
