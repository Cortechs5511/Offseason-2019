.. image:: https://img.shields.io/pypi/v/pint.svg
    :target: https://pypi.python.org/pypi/pint
    :alt: Latest Version

.. image:: https://readthedocs.org/projects/pip/badge/
    :target: http://pint.readthedocs.org/
    :alt: Documentation

.. image:: https://img.shields.io/pypi/l/pint.svg
    :target: https://pypi.python.org/pypi/pint
    :alt: License

.. image:: https://img.shields.io/pypi/pyversions/pint.svg
    :target: https://pypi.python.org/pypi/pint
    :alt: Python Versions

.. image:: https://travis-ci.org/hgrecco/pint.svg?branch=master
    :target: https://travis-ci.org/hgrecco/pint
    :alt: CI

.. image:: https://coveralls.io/repos/github/hgrecco/pint/badge.svg?branch=master 
    :target: https://coveralls.io/github/hgrecco/pint?branch=master
    :alt: Coverage

.. image:: https://readthedocs.org/projects/pint/badge/
    :target: http://pint.readthedocs.org/
    :alt: Docs


